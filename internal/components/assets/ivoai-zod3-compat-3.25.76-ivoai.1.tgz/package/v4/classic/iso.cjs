"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ZodISOTime = exports.ZodISODuration = exports.ZodISODateTime = exports.ZodISODate = void 0;
exports.datetime = datetime;
exports.date = date;
exports.time = time;
exports.duration = duration;
const core = __importStar(require("../core/index.cjs"));
const schemas_js_1 = require("./schemas.cjs");
var schemas_js_2 = require("./schemas.cjs");
Object.defineProperty(exports, "ZodISODate", { enumerable: true, get: function () { return schemas_js_2.ZodISODate; } });
Object.defineProperty(exports, "ZodISODateTime", { enumerable: true, get: function () { return schemas_js_2.ZodISODateTime; } });
Object.defineProperty(exports, "ZodISODuration", { enumerable: true, get: function () { return schemas_js_2.ZodISODuration; } });
Object.defineProperty(exports, "ZodISOTime", { enumerable: true, get: function () { return schemas_js_2.ZodISOTime; } });
function datetime(params) {
    return core._isoDateTime(schemas_js_1.ZodISODateTime, params);
}
function date(params) {
    return core._isoDate(schemas_js_1.ZodISODate, params);
}
function time(params) {
    return core._isoTime(schemas_js_1.ZodISOTime, params);
}
function duration(params) {
    return core._isoDuration(schemas_js_1.ZodISODuration, params);
}

// seal-cjs-exports
(function () {
  var keys = Object.getOwnPropertyNames(exports);
  for (var i = 0; i < keys.length; i++) {
    var desc = Object.getOwnPropertyDescriptor(exports, keys[i]);
    if (!desc || !desc.get || !desc.configurable) continue;
    var value;
    try {
      value = desc.get();
    } catch (e) {
      continue;
    }
    // a circular require may not have settled this one yet, so leave it live
    if (value === undefined) continue;
    Object.defineProperty(exports, keys[i], { value: value, writable: false, enumerable: desc.enumerable, configurable: false });
  }
  Object.freeze(exports);
})();
